arXiv Submission - Fractal-Enhanced Topological Quantum Computing
=============================================================

Build Instructions
------------------
1. pdflatex -interaction=nonstopmode main.tex
2. bibtex main
3. pdflatex -interaction=nonstopmode main.tex
4. pdflatex -interaction=nonstopmode main.tex

Required: pdflatex, bibtex (or equivalent)

Output: main.pdf
