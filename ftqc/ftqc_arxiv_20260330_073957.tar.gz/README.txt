Fractal-Enhanced Topological Quantum Computing
Author: Ross A. Edwards
Affiliation: Aurphyx LLC, Erie, PA
Generated: 2026-03-30 07:40:06

BUILD INSTRUCTIONS:
  pdflatex main.tex
  bibtex main
  pdflatex main.tex
  pdflatex main.tex

CONTACT:
  Email: ross@aurphyx.org
  ORCID: 0009-0008-0539-1289
  GitHub: github.com/rossaedwards/main/tree/main/ftqc

LICENSE: CC BY 4.0
